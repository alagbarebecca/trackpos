<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Sale;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index()
    {
        $user = Auth::user();
        
        $todaySales = Sale::whereDate('created_at', today())
            ->where('status', 'completed')
            ->sum('total');
        
        $todayTransactions = Sale::whereDate('created_at', today())
            ->where('status', 'completed')
            ->count();
        
        $lowStockProducts = Product::whereRaw('stock_quantity <= min_stock_level')
            ->where('status', true)
            ->count();
        
        $topProducts = Product::orderBy('stock_quantity', 'asc')
            ->take(5)
            ->get();
        
        $recentSales = Sale::with(['customer', 'user'])
            ->where('status', 'completed')
            ->orderBy('created_at', 'desc')
            ->take(5)
            ->get();
        
        $totalProducts = Product::where('status', true)->count();
        $totalCustomers = \App\Models\Customer::count();
        $totalSuppliers = \App\Models\Supplier::count();
        
        return view('dashboard', compact(
            'todaySales',
            'todayTransactions',
            'lowStockProducts',
            'topProducts',
            'recentSales',
            'totalProducts',
            'totalCustomers',
            'totalSuppliers'
        ));
    }
}
