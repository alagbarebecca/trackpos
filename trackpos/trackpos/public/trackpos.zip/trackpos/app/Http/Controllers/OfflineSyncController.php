<?php

namespace App\Http\Controllers;

use App\Models\Sale;
use App\Models\SaleItem;
use App\Models\Product;
use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class OfflineSyncController extends Controller
{
    /**
     * Sync offline sales when connection is restored
     */
    public function syncSale(Request $request)
    {
        $request->validate([
            'items' => 'required|array',
            'items.*.product_id' => 'required|integer',
            'items.*.quantity' => 'required|integer|min:1',
            'payment_method' => 'required|string|in:cash,card,mobile',
            'paid_amount' => 'required|numeric|min:0',
            'tax_rate' => 'nullable|numeric|min:0|max:100',
            'tax' => 'nullable|numeric|min:0',
            'discount' => 'nullable|numeric|min:0',
            'customer_id' => 'nullable|integer',
        ]);
        
        DB::beginTransaction();
        
        try {
            // Calculate totals
            $subtotal = 0;
            $itemsData = [];
            
            foreach ($request->items as $item) {
                $product = Product::findOrFail($item['product_id']);
                $quantity = $item['quantity'];
                $itemSubtotal = $product->sell_price * $quantity;
                $subtotal += $itemSubtotal;
                
                $itemsData[] = [
                    'product_id' => $product->id,
                    'quantity' => $quantity,
                    'unit_price' => $product->sell_price,
                    'discount' => 0,
                    'tax' => $itemSubtotal * ($request->tax_rate ?? 0) / 100,
                    'subtotal' => $itemSubtotal,
                ];
            }
            
            $discount = $request->discount ?? 0;
            $taxRate = $request->tax_rate ?? 0;
            $tax = $request->tax ?? ($subtotal - $discount) * $taxRate / 100;
            $total = $subtotal - $discount + $tax;
            $paidAmount = $request->paid_amount;
            $changeAmount = max(0, $paidAmount - $total);
            
            // Generate invoice number
            $lastSale = Sale::orderBy('id', 'desc')->first();
            $invoiceNo = 'INV-' . str_pad(($lastSale ? $lastSale->id + 1 : 1), 5, '0', STR_PAD_LEFT);
            
            // Create sale
            $sale = Sale::create([
                'invoice_no' => $invoiceNo,
                'customer_id' => $request->customer_id,
                'user_id' => auth()->id() ?? 1,
                'subtotal' => $subtotal,
                'discount' => $discount,
                'tax' => $tax,
                'total' => $total,
                'payment_method' => $request->payment_method,
                'paid_amount' => $paidAmount,
                'change_amount' => $changeAmount,
                'status' => 'completed',
                'created_at' => $request->timestamp ? \Carbon\Carbon::parse($request->timestamp) : now(),
            ]);
            
            // Create sale items and update stock
            foreach ($itemsData as $itemData) {
                SaleItem::create([
                    'sale_id' => $sale->id,
                    'product_id' => $itemData['product_id'],
                    'quantity' => $itemData['quantity'],
                    'unit_price' => $itemData['unit_price'],
                    'discount' => $itemData['discount'],
                    'tax' => $itemData['tax'],
                    'subtotal' => $itemData['subtotal'],
                ]);
                
                // Update product stock
                Product::where('id', $itemData['product_id'])->decrement('stock_quantity', $itemData['quantity']);
            }
            
            DB::commit();
            
            return response()->json([
                'success' => true,
                'sale_id' => $sale->id,
                'invoice_no' => $invoiceNo,
                'message' => 'Sale synced successfully'
            ]);
            
        } catch (\Exception $e) {
            DB::rollBack();
            
            return response()->json([
                'success' => false,
                'message' => 'Sync failed: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Get pending sync count
     */
    public function getPendingCount()
    {
        // This would typically check a database table for pending syncs
        // For now, return 0 as pending is handled client-side
        return response()->json(['pending' => 0]);
    }
}