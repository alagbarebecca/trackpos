<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\StockAdjustment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class StockAdjustmentController extends Controller
{
    public function index(Request $request)
    {
        $query = StockAdjustment::with(['product', 'user'])->orderBy('created_at', 'desc');
        
        if ($request->product_id) {
            $query->where('product_id', $request->product_id);
        }
        if ($request->type) {
            $query->where('type', $request->type);
        }
        if ($request->from_date) {
            $query->whereDate('created_at', '>=', $request->from_date);
        }
        if ($request->to_date) {
            $query->whereDate('created_at', '<=', $request->to_date);
        }
        
        $adjustments = $query->paginate(20);
        
        return view('stock-adjustments.index', compact('adjustments'));
    }

    public function create()
    {
        $products = Product::orderBy('name')->get();
        return view('stock-adjustments.create', compact('products'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer',
            'type' => 'required|in:addition,deduction,correction,returned',
            'reason' => 'required|string|max:500',
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        $product = Product::findOrFail($request->product_id);
        $previousQty = $product->stock_quantity;
        
        // Calculate new quantity
        $newQty = $previousQty + $request->quantity;
        
        // Validate deduction doesn't go below zero
        if ($newQty < 0) {
            return back()->with('error', 'Cannot deduct more than current stock. Current: ' . $previousQty);
        }
        
        // Update product stock
        $product->update(['stock_quantity' => $newQty]);
        
        // Record adjustment
        StockAdjustment::create([
            'product_id' => $product->id,
            'user_id' => auth()->id(),
            'quantity' => $request->quantity,
            'previous_quantity' => $previousQty,
            'new_quantity' => $newQty,
            'type' => $request->type,
            'reason' => $request->reason,
        ]);
        
        $action = $request->quantity > 0 ? 'added' : 'removed';
        return redirect()->route('stock-adjustments.index')
            ->with('success', "Stock {$action}: {$product->name} ({$previousQty} → {$newQty})");
    }

    public function show(StockAdjustment $adjustment)
    {
        return view('stock-adjustments.show', compact('adjustment'));
    }
}