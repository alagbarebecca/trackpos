<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Schema;
use App\Models\Setting;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Share settings globally to all views (only if table exists)
        if (Schema::hasTable('settings')) {
            $settings = Setting::pluck('value', 'key')->toArray();
            
            View::share('appName', $settings['app_name'] ?? 'Loop POS');
            View::share('currencySymbol', $settings['currency_symbol'] ?? '$');
            View::share('defaultTaxRate', $settings['default_tax_rate'] ?? 0);
            View::share('companyName', $settings['company_name'] ?? '');
            View::share('companyAddress', $settings['company_address'] ?? '');
            View::share('companyPhone', $settings['company_phone'] ?? '');
            View::share('companyEmail', $settings['company_email'] ?? '');
            View::share('companyTaxId', $settings['company_tax_id'] ?? '');
        } else {
            // Default values when settings table doesn't exist yet
            View::share('appName', 'Loop POS');
            View::share('currencySymbol', '$');
            View::share('defaultTaxRate', 0);
            View::share('companyName', '');
            View::share('companyAddress', '');
            View::share('companyPhone', '');
            View::share('companyEmail', '');
            View::share('companyTaxId', '');
        }
    }
}
