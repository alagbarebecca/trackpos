<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Role;
use App\Models\Permission;

class RolesPermissionsSeeder extends Seeder
{
    public function run(): void
    {
        // Create Permissions
        $permissions = [
            ['name' => 'View Dashboard', 'slug' => 'view-dashboard', 'description' => 'Can view dashboard'],
            ['name' => 'View POS', 'slug' => 'view-pos', 'description' => 'Can access POS'],
            ['name' => 'Process Sales', 'slug' => 'process-sales', 'description' => 'Can process sales transactions'],
            ['name' => 'View Products', 'slug' => 'view-products', 'description' => 'Can view products'],
            ['name' => 'Manage Products', 'slug' => 'manage-products', 'description' => 'Can add/edit/delete products'],
            ['name' => 'View Customers', 'slug' => 'view-customers', 'description' => 'Can view customers'],
            ['name' => 'Manage Customers', 'slug' => 'manage-customers', 'description' => 'Can add/edit/delete customers'],
            ['name' => 'View Reports', 'slug' => 'view-reports', 'description' => 'Can view reports'],
            ['name' => 'Manage Settings', 'slug' => 'manage-settings', 'description' => 'Can change system settings'],
            ['name' => 'Manage Users', 'slug' => 'manage-users', 'description' => 'Can manage users'],
            ['name' => 'Manage Roles', 'slug' => 'manage-roles', 'description' => 'Can manage roles and permissions'],
            ['name' => 'View Purchases', 'slug' => 'view-purchases', 'description' => 'Can view purchases'],
            ['name' => 'Manage Purchases', 'slug' => 'manage-purchases', 'description' => 'Can create/manage purchases'],
            ['name' => 'View Suppliers', 'slug' => 'view-suppliers', 'description' => 'Can view suppliers'],
            ['name' => 'Manage Suppliers', 'slug' => 'manage-suppliers', 'description' => 'Can manage suppliers'],
        ];

        foreach ($permissions as $perm) {
            Permission::firstOrCreate(['slug' => $perm['slug']], $perm);
        }

        // Create Roles
        $adminRole = Role::firstOrCreate(['name' => 'admin'], ['description' => 'Administrator with full access']);
        $managerRole = Role::firstOrCreate(['name' => 'manager'], ['description' => 'Manager with limited admin access']);
        $cashierRole = Role::firstOrCreate(['name' => 'cashier'], ['description' => 'Cashier with POS access only']);

        // Assign all permissions to admin
        $adminRole->permissions()->sync(Permission::pluck('id'));

        // Assign specific permissions to manager
        $managerPermissions = Permission::whereIn('slug', [
            'view-dashboard', 'view-pos', 'process-sales', 'view-products', 'manage-products',
            'view-customers', 'manage-customers', 'view-reports', 'view-purchases', 'manage-purchases',
            'view-suppliers', 'manage-suppliers'
        ])->pluck('id');
        $managerRole->permissions()->sync($managerPermissions);

        // Assign specific permissions to cashier
        $cashierPermissions = Permission::whereIn('slug', [
            'view-dashboard', 'view-pos', 'process-sales', 'view-products', 'view-customers'
        ])->pluck('id');
        $cashierRole->permissions()->sync($cashierPermissions);
    }
}