<?php

use App\Http\Controllers\AuditLogController;
use App\Http\Controllers\ZReportController;
use App\Http\Controllers\OfflineSyncController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PosController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProductImportController;
use App\Http\Controllers\PurchaseController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\SalesController;
use App\Http\Controllers\CustomerReportController;
use App\Http\Controllers\PaymentReportController;
use App\Http\Controllers\ReturnController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\SupplierController;
use App\Http\Controllers\StockAdjustmentController;
use App\Http\Controllers\TaxReportController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\PermissionController;
use Illuminate\Support\Facades\Route;

// Auth Routes
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Protected Routes
Route::middleware('auth')->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/audit-logs', [AuditLogController::class, 'index'])->name('audit-logs.index');

    // Returns
    Route::resource('returns', ReturnController::class)->except(['edit', 'update']);

    Route::get('/reports/z-report', [ZReportController::class, 'index'])->name('reports.z-report');
    Route::get('/reports/z-report/print', [ZReportController::class, 'print'])->name('reports.z-report.print');

    // Stock Adjustments
    Route::resource('stock-adjustments', StockAdjustmentController::class)->except(['edit', 'update']);

    // POS Routes
    Route::get('/pos', [PosController::class, 'index'])->name('pos.index');
    Route::get('/pos/search', [PosController::class, 'searchProducts']);
    Route::get('/pos/barcode', [PosController::class, 'findByBarcode']);
    Route::post('/pos/sale', [PosController::class, 'storeSale'])->name('pos.sale');
    Route::post('/pos/sync-sale', [OfflineSyncController::class, 'syncSale'])->name('pos.sync-sale');
    
    // Hold Sale Routes
    Route::post('/pos/hold', [PosController::class, 'holdSale'])->name('pos.hold');
    Route::get('/pos/held-sales', [PosController::class, 'getHeldSales']);
    Route::get('/pos/resume/{heldSale}', [PosController::class, 'resumeSale']);
    Route::delete('/pos/held-sale/{heldSale}', [PosController::class, 'deleteHeldSale']);
    
    // Products Routes
    Route::get('/products', [ProductController::class, 'index'])->name('products.index');
    Route::post('/products', [ProductController::class, 'store'])->name('products.store');
    Route::put('/products/{product}', [ProductController::class, 'update'])->name('products.update');
    Route::delete('/products/{product}', [ProductController::class, 'destroy'])->name('products.destroy');
    Route::get('/products/low-stock', [ProductController::class, 'lowStock'])->name('products.low-stock');
    Route::get('/products/import', [ProductImportController::class, 'showImportForm'])->name('products.import');
    Route::post('/products/import', [ProductImportController::class, 'import'])->name('products.import.store');
    Route::get('/products/import/template', [ProductImportController::class, 'downloadTemplate'])->name('products.import.template');
    
    // Categories Routes
    Route::get('/categories', [CategoryController::class, 'index'])->name('categories.index');
    Route::post('/categories', [CategoryController::class, 'store'])->name('categories.store');
    Route::put('/categories/{category}', [CategoryController::class, 'update'])->name('categories.update');
    Route::delete('/categories/{category}', [CategoryController::class, 'destroy'])->name('categories.destroy');
    
    // Sales Routes
    Route::get('/sales', [SalesController::class, 'index'])->name('sales.index');
    Route::get('/sales/{sale}', [SalesController::class, 'show'])->name('sales.show');
    
    // Purchases Routes
    Route::get('/purchases', [PurchaseController::class, 'index'])->name('purchases.index');
    
    // Customers Routes
    Route::get('/customers', [CustomerController::class, 'index'])->name('customers.index');
    Route::post('/customers', [CustomerController::class, 'store'])->name('customers.store');
    Route::put('/customers/{customer}', [CustomerController::class, 'update'])->name('customers.update');
    Route::delete('/customers/{customer}', [CustomerController::class, 'destroy'])->name('customers.destroy');
    
    // Suppliers Routes
    Route::get('/suppliers', [SupplierController::class, 'index'])->name('suppliers.index');
    Route::post('/suppliers', [SupplierController::class, 'store'])->name('suppliers.store');
    Route::put('/suppliers/{supplier}', [SupplierController::class, 'update'])->name('suppliers.update');
    Route::delete('/suppliers/{supplier}', [SupplierController::class, 'destroy'])->name('suppliers.destroy');
    
    // Reports Routes
    Route::get('/reports', [ReportController::class, 'index'])->name('reports.index');
    Route::get('/reports/daily-sales', [ReportController::class, 'dailySales'])->name('reports.daily-sales');
    Route::get('/reports/daily-sales/print', [ReportController::class, 'printDailySales'])->name('reports.print-daily');
    Route::get('/reports/daily-sales/export', [ReportController::class, 'exportDailySales'])->name('reports.export-daily');
    Route::get('/reports/product-sales', [ReportController::class, 'productSales'])->name('reports.product-sales');
    Route::get('/reports/stock', [ReportController::class, 'stockReport'])->name('reports.stock');
    Route::get('/reports/profit-loss', [ReportController::class, 'profitLoss'])->name('reports.profit-loss');
    Route::get('/reports/tax', [TaxReportController::class, 'index'])->name('reports.tax');
    Route::get('/reports/tax/print', [TaxReportController::class, 'print'])->name('reports.tax.print');
    Route::get('/reports/tax/export', [TaxReportController::class, 'export'])->name('reports.tax.export');
    Route::get('/reports/customer-sales', [CustomerReportController::class, 'index'])->name('reports.customer-sales');
    Route::get('/reports/customer-sales/export', [CustomerReportController::class, 'export'])->name('reports.customer-sales.export');
    Route::get('/reports/payment-method', [PaymentReportController::class, 'index'])->name('reports.payment-method');
    Route::get('/reports/payment-method/export', [PaymentReportController::class, 'export'])->name('reports.payment-method.export');
    
    // Users Routes
    Route::get('/users', [UserController::class, 'index'])->name('users.index');
    Route::post('/users', [UserController::class, 'store'])->name('users.store');
    Route::put('/users/{user}', [UserController::class, 'update'])->name('users.update');
    Route::delete('/users/{user}', [UserController::class, 'destroy'])->name('users.destroy');
    
    // Roles Routes
    Route::get('/roles', [RoleController::class, 'index'])->name('roles.index');
    Route::post('/roles', [RoleController::class, 'store'])->name('roles.store');
    Route::put('/roles/{role}', [RoleController::class, 'update'])->name('roles.update');
    Route::delete('/roles/{role}', [RoleController::class, 'destroy'])->name('roles.destroy');
    Route::post('/roles/assign-permissions/{role}', [RoleController::class, 'assignPermissions'])->name('roles.assign-permissions');
    Route::post('/roles/assign-user', [RoleController::class, 'assignToUser'])->name('roles.assign-user');
    
    // Permissions Routes
    Route::get('/permissions', [PermissionController::class, 'index'])->name('permissions.index');
    Route::post('/permissions', [PermissionController::class, 'store'])->name('permissions.store');
    Route::put('/permissions/{permission}', [PermissionController::class, 'update'])->name('permissions.update');
    Route::delete('/permissions/{permission}', [PermissionController::class, 'destroy'])->name('permissions.destroy');
    
    // Settings Route
    Route::get('/settings', [SettingsController::class, 'index'])->name('settings.index');
    Route::post('/settings', [SettingsController::class, 'update'])->name('settings.update');
    
    // Units routes
    Route::resource('units', \App\Http\Controllers\UnitController::class)->except(['show', 'edit', 'update']);
    
    // Loyalty routes
    Route::resource('loyalty', \App\Http\Controllers\LoyaltyController::class)->except(['show', 'edit', 'update']);
    
    // Purchase Orders route  
    Route::resource('purchase-orders', \App\Http\Controllers\PurchaseOrderController::class)->except(['show', 'edit', 'update']);
    
    // Transfers route
    Route::resource('transfers', \App\Http\Controllers\TransferController::class)->except(['show', 'edit', 'update']);
    
    // Locations route
    Route::resource('locations', \App\Http\Controllers\LocationController::class)->except(['show', 'edit', 'update']);
    
    // Import/Export route
    Route::resource('import-export', \App\Http\Controllers\ImportExportController::class)->except(['show', 'edit', 'update']);
    
    // Waste route
    Route::resource('waste', \App\Http\Controllers\WasteController::class)->except(['show', 'edit', 'update']);
    
    // Expenses route
    Route::resource('expenses', \App\Http\Controllers\ExpenseController::class)->except(['show', 'edit', 'update']);
    
    // Staff route
    Route::resource('staff', \App\Http\Controllers\StaffController::class)->except(['show', 'edit', 'update']);
    
    // Staff timeclock
    Route::get('/staff/timeclock', [StaffController::class, 'timeclock'])->name('staff.timeclock');
});

// Sales Routes (additional)
Route::get('/sales/{sale}/print', [SalesController::class, 'printReceipt'])->name('sales.print');
Route::get('/sales/search', [SalesController::class, 'search']);
